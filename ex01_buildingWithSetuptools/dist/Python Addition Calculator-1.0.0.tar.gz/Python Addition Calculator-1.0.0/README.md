# Exercise: Build a project with setuptools

## The tasks include:
1. Create a new python project with setuptools.
2. Define the metadata, dependencies, and entry points.
3. Build the project and grenerate a distributable package.
4. Explore setuptools' command-line options for customising the build process.
5. Include links to github and social media.