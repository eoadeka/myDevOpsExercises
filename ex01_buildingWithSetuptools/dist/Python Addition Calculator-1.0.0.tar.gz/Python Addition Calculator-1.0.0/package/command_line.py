import buildAProjectWithSetUpTools as builder

def main():
    print(builder.addition(1,3))